import React, { useCallback, useState } from 'react';
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  addEdge,
  applyNodeChanges,
  applyEdgeChanges,
  Node,
  Edge,
  NodeChange,
  EdgeChange,
  Connection,
} from 'reactflow';
import 'reactflow/dist/style.css';
import testData from './test-canvas-data.json';

const initialNodes: Node[] = [
  { id: '1', position: { x: 80, y: 60 }, data: { label: 'Старт' }, type: 'input' },
  { id: '2', position: { x: 280, y: 200 }, data: { label: 'Таск 1' } },
  { id: '3', position: { x: 480, y: 200 }, data: { label: 'Таск 2' } },
];

const initialEdges: Edge[] = [
  { id: 'e1-2', source: '1', target: '2', animated: true },
  { id: 'e2-3', source: '2', target: '3', animated: true },
];

export const CanvasPage: React.FC = () => {
const [nodes, setNodes] = useState<Node[]>(testData.nodes);
const [edges, setEdges] = useState<Edge[]>(testData.edges);

  const onNodesChange = useCallback(
    (changes: NodeChange[]) => setNodes((nds) => applyNodeChanges(changes, nds)),
    []
  );

  const onEdgesChange = useCallback(
    (changes: EdgeChange[]) => setEdges((eds) => applyEdgeChanges(changes, eds)),
    []
  );

  const onConnect = useCallback(
    (connection: Edge | Connection) => setEdges((eds) => addEdge(connection, eds)),
    []
  );

  return (
    <div style={{ width: '100vw', height: '100vh', background: '#f6f8fb' }}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        fitView
        nodesDraggable
        nodesConnectable
        elementsSelectable
        panOnDrag
        zoomOnScroll
      >
        <MiniMap />
        <Background />
        <Controls showInteractive />
      </ReactFlow>
    </div>
  );
};

export default CanvasPage;
